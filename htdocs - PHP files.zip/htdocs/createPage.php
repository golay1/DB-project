<?php
session_start();
$found = 0;
$pageName = $_GET['page_name'];
$pageDesc = $_GET['page_desc'];
$pageCat = $_GET['page_cat'];
$pageDetails = array();
$conn = new mysqli('localhost', 'root', '', 'social_network_two');

// Check connection
if ($conn->connect_error) {
	die("Connection failed: " . $conn->connect_error);
} 

$sql2 = 'INSERT INTO page (page_name, description, category, admin_id) VALUES ("'.$pageName.'", "'.$pageDesc.'", "'.$pageCat.'", '.$_SESSION['userid'].')';
//echo $sql2;
$result2 = $conn->query($sql2);

$sql = "SELECT * from page where page_name like '%".$pageName."%'";

$result = $conn->query($sql);
$row = $result->fetch_assoc();
$adminID = $row['admin_id'];
$pageId = $row['page_id'];

$pageDetails[] = array(
						'page_ID' => $pageId,
						'adminID' => $adminID
		);

echo json_encode($pageDetails);

?>