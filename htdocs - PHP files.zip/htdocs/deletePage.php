<?php
session_start();
$page_id = $_GET['page_id'];
//echo $uname;
// Create connection
$userDetails = array();
$conn = new mysqli('localhost', 'root', '', 'social_network_two');

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
//echo "Connected successfully";
$sql3 = "DELETE FROM `page` WHERE page_id = ".$page_id."";
$result = $conn->query($sql3);

$sql4 = "SELECT * FROM `post` WHERE page_id = ".$page_id."";
$result = $conn->query($sql4);

$sql4 = "DELETE FROM `pagemembers` WHERE page_id = ".$page_id."";
$result = $conn->query($sql4);

$sql2 = "SELECT * from profile where profile_id like '%".$_SESSION['userid']."%'";
$result = $conn->query($sql2);
$row1 = $result->fetch_assoc();
$pid = $row1['profile_id'];
$fname = $row1['fname'];
$lname = $row1['lname'];
$username = $row1['username'];
$mobile_no = $row1['mobile_no'];
$email = $row1['email'];


	

$userDetails[] = array(
						'profile_id' => $pid,
						'first_name' => $fname,
						'last_name' => $lname,
						'u_name' => $username,
						'mobile_no' => $mobile_no,
						'eId' => $email
);
	
echo json_encode($userDetails);


$conn->close();
?>