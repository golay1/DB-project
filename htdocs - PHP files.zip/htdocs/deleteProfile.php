<?php
session_start();
$profile_id = $_GET['profile_id'];
//echo $uname;
// Create connection
$userDetails = array();
$conn = new mysqli('localhost', 'root', '', 'social_network_two');

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
//echo "Connected successfully";
$sql3 = "DELETE FROM `profile` WHERE profile_id = ".$profile_id."";
$result = $conn->query($sql3);

$sql3 = "DELETE FROM `comment` WHERE commenter_id = ".$profile_id."";
$result = $conn->query($sql3);

$sql3 = "DELETE FROM `page` WHERE admin_id = ".$profile_id."";
$result = $conn->query($sql3);

$sql3 = "DELETE FROM `pagemembers` WHERE member_id = ".$profile_id."";
$result = $conn->query($sql3);

$sql3 = "DELETE FROM `post` WHERE posted_by = ".$profile_id."";
$result = $conn->query($sql3);

$sql3 = "DELETE FROM `post_likes` WHERE liked_by = ".$profile_id."";
$result = $conn->query($sql3);

 if(isset($_SESSION['userid']))
                {
                unset($_SESSION['userid']);
                }
?>