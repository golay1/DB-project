<?php
$pageID = $_GET['page_Id'];
//echo $pageID;

$pageDetails = array();
$conn = new mysqli('localhost', 'root', '', 'social_network_two');

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
//echo "Connected successfully";
$sql = "SELECT * from page where page_id = ".$pageID."";

$result = $conn->query($sql);
$row = $result->fetch_assoc();
$page_id = $row['page_id'];
$admin_id = $row['admin_id'];
$pageDetails []= array('page_ID' => $page_id,
					 'adminID' => $admin_id);
					 
echo json_encode($pageDetails);
?>