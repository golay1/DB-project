<?php
session_start();
$found = 0;
$date = $_GET['date'];
$pageID = $_GET['page_Id'];

$pageDetails = array();
$conn = new mysqli('localhost', 'root', '', 'social_network_two');

// Check connection
if ($conn->connect_error) {
	die("Connection failed: " . $conn->connect_error);
} 


	$sql = 'SELECT * from post where page_id = '.$pageID.' and post_date like "%'.$date.'%"';
	$result = $conn->query($sql);
if ($result->num_rows > 0) {
	while($row = $result->fetch_assoc()){
		$found = 0;
		$sql3 = "SELECT * from profile where profile_id =".$row['posted_by']."";
		$result3 = $conn->query($sql3);
		$row3 = $result3->fetch_assoc();
		$postedByFname = $row3['fname'];
		$postedByLname = $row3['lname'];
		$sql4 = "SELECT liked_by from post_likes where post_id =".$row['post_id']."";
		$result4 = $conn->query($sql4);
		while($row4 = $result4->fetch_assoc()){
			if ($_SESSION['userid'] == $row4['liked_by']){
				$found = 1;
			}
		}
		
		$sql5 = "SELECT count(*) as total from post_likes where post_id=".$row['post_id']."";
		$result5 = $conn->query($sql5);
		$row5 = $result5->fetch_assoc();
		$totalLikes = $row5['total'];
		
		$pageDetails[] = array(
						'page_ID' => $pageID,
						'postedByFname' => $postedByFname,
						'postedByLname' => $postedByLname,
						'found' => $found,
						'totalLikes' => $totalLikes,
						'postID' => $row['post_id'],
						'postContent' => $row['content']
		);
	}
}



echo json_encode($pageDetails);

?>