<!DOCTYPE HTML>
<html>
<head>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

	<!-- Optional theme -->
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">
</head>
<body style="color:#6d6d6d">
<!-- --------- NAVBAR -------------->
	<nav class="navbar navbar-default">
	  <div class="container-fluid">
		<div class="navbar-header">
		  <a style="text-decoration:none"><h3>DB1 Project</h3></a>
		</div>
	  </div>
	</nav>
<!--- SIGN  UP FORM --->
	<div class = "container">
		<div class = "row">
			<div class="col-md-offset-1">
				<div class="panel panel-default">
				  <!-- <div class="panel-heading">Panel heading without title</div> -->
				  <div class="panel-body">
						<div class= "container">
							<div class="row">
								
								<div class = "col-md-offset-2 col-md-3" style="padding-right:3%;">
									<h3>Sign in</h3>
									<form id="signInForm">
										  <div class="form-group">
											<label for="">Email address</label>
											<input type="email" class="form-control" id="emailAdd" placeholder="Email">
										  </div>
										  <div class="form-group">
											<label for="password">Password</label>
											<input type="password" class="form-control" id="password" placeholder="Password">
										  </div>
										  <button type="submit" class="btn btn-default" onClick="">Submit</button>
									</form>
								</div>
								<div class = "col-md-3" style="padding-left:3%; border-left:1px solid #6d6d6d;">
									<h3>Sign up</h3>
									<form id="signUpForm">
										  <div class="form-group">
											<label for="emailAddSignUp">Email address</label>
											<input type="email" class="form-control" id="emailAddSignUp" placeholder="Email">
										  </div>
										  <div class="form-group">
											<label for="passwordSignUp">Password</label>
											<input type="password" class="form-control" id="passwordSignUp" placeholder="Password">
										  </div>
										  <div class="form-group">
											<label for="firstName">First name</label>
											<input type="text" class="form-control" id="firstName" placeholder="first name">
										  </div>
										  <div class="form-group">
											<label for="lastName">Last name</label>
											<input type="text" class="form-control" id="lastName" placeholder="last name">
										  </div>
										  <div class="form-group">
											<label for="username">Username</label>
											<input type="text" class="form-control" id="username" placeholder="username">
										  </div>
										  <div class="form-group">
											<label for="mobNo">Mobile Number</label>
											<input type="text" class="form-control" id="mobNo" placeholder="Mobile number">
										  </div>
										  <button type="submit" class="btn btn-default">Submit</button>
									</form>
								</div>
								<div class="col-md-12"></br></div>
							</div>
						</div>
				  </div>
				</div>
			</div>
		</div>
	</div>
	<!-- jquery CDN -->
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
	<!-- Latest compiled and minified JavaScript -->
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
	
	<script type="text/javascript">
		/* function signInSubmit(){
			var emailSignIn = document.getElementById("emailAdd").value;
			var passwordSignIn = document.getElementById("password").value;
			console.log(emailSignIn);
			console.log(passwordSignIn);
		} */
		//**********************************************************
		//**********************************************************
		//**********************************************************
		// function to submit username and password
		//**********************************************************
		//**********************************************************
		//**********************************************************
		$("#signInForm").submit(function(){
			var emailSignIn = $("#emailAdd").val();
			var passwordSignIn = $("#password").val();
			console.log(emailSignIn);
			console.log(passwordSignIn);
			verifySignIn(emailSignIn, passwordSignIn);
		});
		
		function verifySignIn(emailSignIn, passwordSignIn){
			var res;
			$.ajax({
				url: 'validateCredentials.php',
				type: 'GET',
				data: {'eSignIn': emailSignIn, 'psswd': passwordSignIn},
				success: function(response){
					////alert(response);
					res = JSON.parse(response);
					var uid=res[0]['profile_id'];
					var fname=res[0]['first_name'];
					var lname=res[0]['last_name'];
					var uname=res[0]['u_name'];
					var mobNo=res[0]['mobile_no'];
					var eId=res[0]['eId'];
					
					var link = "http://localhost/profile.php?profileID="+uid+"&fname="+fname+"&lname="+lname+"&uname="+uname+"&mobNo="+mobNo+"&eid="+eId+"";
					window.location.assign(link); 
					/* if(res == 'True'){
						window.location.assign(); 
					} */
				}
				
			});
		}
		
		//**********************************************************
		//**********************************************************
		//**********************************************************
		// FUNCTION TO CREATE A NEW ACCOUNT
		//**********************************************************
		//**********************************************************
		//**********************************************************
		$("#signUpForm").submit(function(){
			var emailSignUp = $("#emailAddSignUp").val();
			var passwordSignUp = $("#passwordSignUp").val();
			var fnameSignUp = $("#firstName").val();
			var lnameSignUp = $("#lastName").val();
			var unameSignUp = $("#username").val();
			var mobNoSignUp = $("#mobNo").val();
			submitSignUpForm(emailSignUp,passwordSignUp,fnameSignUp,lnameSignUp,unameSignUp, mobNoSignUp);
		});
		
		function submitSignUpForm(emailSignUp,passwordSignUp,fnameSignUp,lnameSignUp,unameSignUp, mobNoSignUp){
			var res;
			$.ajax({
				url: 'signUpSubmit.php',
				type: 'GET',
				data: {'eSignIn': emailSignUp, 'psswd': passwordSignUp, 'fname': fnameSignUp, 'lname': lnameSignUp, 'uname': unameSignUp, 'mobNo':mobNoSignUp},
				success: function(response){
					try{
						res = JSON.parse(response);

						var uid=res[0]['profile_id'];
						var fname=res[0]['first_name'];
						var lname=res[0]['last_name'];
						var uname=res[0]['u_name'];
						var mobNo=res[0]['mobile_no'];
						
						var link = "http://localhost/profile.php?profileID="+uid+"&fname="+fname+"&lname="+lname+"&uname="+uname+"&mobNo="+mobNo+"";
						window.location.assign(link); 
					}
					catch{
						//alert(response);
					}
						
				}
				
			});
		}
		
	</script>
</body>
</html>