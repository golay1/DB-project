<?php
session_start();
$found = 0;
$postId = $_GET['post_Id'];
$pageDetails = array();
$conn = new mysqli('localhost', 'root', '', 'social_network_two');

// Check connection
if ($conn->connect_error) {
	die("Connection failed: " . $conn->connect_error);
} 
//echo "Connected successfully";
$sql4 = "SELECT liked_by from post_likes where post_id = ".$postId."";
//echo $sql4;
$result4 = $conn->query($sql4);
while($row4 = $result4->fetch_assoc()){
	if ($_SESSION['userid'] == $row4['liked_by']){
		$found = 1;
	}
}


$sql2 = "SELECT page_id from post where post_id=".$postId."";
$result2 = $conn->query($sql2);
$row2 = $result2->fetch_assoc();
$pageId = $row2['page_id'];

$sql3 = "SELECT admin_id from page where page_id=".$pageId."";
$result3 = $conn->query($sql3);
$row3 = $result3->fetch_assoc();
$adminId = $row3['admin_id'];
if ($found == 1){
	$sql = "DELETE FROM post_likes WHERE post_id=".$postId." and liked_by = ".$_SESSION['userid']."";
	$result = $conn->query($sql);
	
}
else{
	
	$sql = "INSERT INTO `post_likes`(`post_id`, `page_id`, `liked_by`) VALUES (".$postId.",".$pageId.",".$_SESSION['userid'].")";
	$result = $conn->query($sql);
	
	
	
}

$pageDetails[] = array(
						'page_id' => $pageId,
						'admin_id' => $adminId
);
echo json_encode($pageDetails);
?>