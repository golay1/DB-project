<?php
session_start();
$profile_id = $_GET['profile_id'];
//echo $uname;
// Create connection

 if(isset($_SESSION['userid']))
                {
                unset($_SESSION['userid']);
                }
?>