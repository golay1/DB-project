<?php
session_start();
$found = 0;
$pageId = $_GET['page_Id'];
$newPost = $_GET['post_text'];
$pageDetails = array();
$conn = new mysqli('localhost', 'root', '', 'social_network_two');

// Check connection
if ($conn->connect_error) {
	die("Connection failed: " . $conn->connect_error);
} 

$sql2 = 'INSERT INTO post (post_date, content, post_type, posted_by, page_id) VALUES (CURRENT_TIMESTAMP, "'.$newPost.'", "text", '.$_SESSION['userid'].', '.$pageId.')';
//echo $sql2;
$result2 = $conn->query($sql2);

$sql = "SELECT * from page where page_id =".$pageId."";

$result = $conn->query($sql);
$row = $result->fetch_assoc();
$adminID = $row['admin_id'];

$pageDetails[] = array(
						'page_ID' => $pageId,
						'adminID' => $adminID
		);

echo json_encode($pageDetails);

?>