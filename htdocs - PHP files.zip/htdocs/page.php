<!DOCTYPE HTML>
<html>
<head>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

	<!-- Optional theme -->
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">
	
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.5.0/css/all.css" integrity="sha384-B4dIYHKNBt8Bc12p+WXckhzcICo0wtJAoU8YZTY5qE0Id1GSseTk6S+L3BlXeVIU" crossorigin="anonymous">
	
	<style type="text/css">
		a:link{
			text-decoration:none;
		}
	</style>
</head>
<body style="color:#6d6d6d">
<!-- --------- NAVBAR -------------->
<?php
	
			
				session_start();
				if(!isset($_SESSION['userid']))
				{
						header("location: index.php");
				}
				else{
					if($_SESSION['userid'] == $_GET['adminID']){
						
						$profID = $_GET['adminID'];
						$pageId = $_GET['page_Id'];
						$conn = new mysqli('localhost', 'root', '', 'social_network_two');
						
						// Check connection
						if ($conn->connect_error) {
							die("Connection failed: " . $conn->connect_error);
						} 
						//echo "Connected successfully";
						
						$sql8 = "SELECT * from profile where profile_id =".$_SESSION['userid']."";
						$result8 = $conn->query($sql8);
						$row8 = $result8->fetch_assoc();
						$curfname = $row8['fname'];
						$curlname = $row8['lname'];
						echo '<nav class="navbar navbar-default">
						  <div class="container-fluid">
							<div class="navbar-header">
							  
							  <a class="redirectToProfile" href="#" id="'.$row8['profile_id'].'" class="container-fluid-nav text-center"><h3>'.$curfname.' '.$curlname.'</h3></a>
							</div>
						  </div>
						</nav>';
						
						echo '<div class="container">
							<div class="row center-block">';
				
						$profID = $_GET['adminID'];
						$pageId = $_GET['page_Id'];
						$conn = new mysqli('localhost', 'root', '', 'social_network_two');
						
						// Check connection
						if ($conn->connect_error) {
							die("Connection failed: " . $conn->connect_error);
						} 
						//echo "Connected successfully";
						$sql = "SELECT * from page where page_Id =".$pageId."";
						$result = $conn->query($sql);
						$row = $result->fetch_assoc();
						$pageName = $row['page_name'];
						$pageDesc = $row['description'];
						$pageCat = $row['category'];
						
						
						$sql2 = "SELECT * from profile where profile_id =".$profID."";
						$result2 = $conn->query($sql2);
						$row2 = $result2->fetch_assoc();
						$adminFname = $row2['fname'];
						$adminLname = $row2['lname'];
						
						echo '<div class="col-md-offset-2 col-md-10">
						<span style="display: inline-flex"><h1>'.$pageName.' </h1><a href=# data-toggle="modal" data-target="#updatePage'.$pageId.'"><i class="far fa-edit"></i></a></span>
						</div>';
						echo '<div class="col-md-offset-2 col-md-7">
						<div class="col-md-12"><p><b>created by: </b>'.$adminFname.' '.$adminLname.'</p></div>
						<div class="col-md-12"><p><span><b>category: </b></span>'.$pageCat.'</p></div>
						<div class="col-md-12"><p><span><b>description: </b></span>'.$pageDesc.'</p></div>
						
						</br>
						</br>
						
						<div class="col-md-3"><i class="far fa-trash-alt"></i><a href="#" data-toggle="modal" data-target="#deletePage'.$pageId.'"> delete page</a></div>
						<div class="col-md-3"><i class="fas fa-users"></i><a href="#" data-toggle="modal" data-target="#viewMembers'.$pageId.'"> view members</a></div>
						</div>
					
				</div>
			</div>
			<div class = "container">
				<div class = "row center-block">
					<div class = "col-md-offset-1 col-md-12" style="padding-top:50px;">';
						echo '<div class="col-md-offset-1 col-md-9">
							<form class="form-inline">
								  <div class="form-group">
									<label class="sr-only" for="pickDate"></label>
									<div class="input-group">
									  <div class="input-group-addon"><i class="fas fa-calendar-alt"></i></div>
									  <input type="date" class="form-control" id="pickDate" placeholder="">
									  <!--<div class="input-group-addon">.00</div>-->
									</div>
								  </div>
								  <button type="button" class="btn btn-primary datePick" id="datePick'.$pageId.'">Go!</button>
								</form>
						</div>';
						echo '<div class="col-md-offset-1 col-md-9">
							<div class = "post-post">
							<form id="postAPost">
							<div class="form-group">
							  <textarea class="form-control" rows="5" id="postBox">Whats on your mind?</textarea>
							</div>
							<button type="button" class="btn btn-primary '.$pageId.'" id="newPost">Post</button>
							</form>
						</div>
						</div>';

						
						$sql = "SELECT * from post where page_id =".$pageId."";

						$result = $conn->query($sql);
						if ($result->num_rows > 0) {
							while($row = $result->fetch_assoc()){
								$sql3 = "SELECT * from profile where profile_id =".$row['posted_by']."";
								$result3 = $conn->query($sql3);
								$row3 = $result3->fetch_assoc();
								$postedByFname = $row3['fname'];
								$postedByLname = $row3['lname'];
								echo '<div class="postsToAppend">
								<div class="col-md-offset-1 col-md-9">
									<h3>'.$postedByFname.' '.$postedByLname.' : </h3>
								</div>
								<div class="col-md-offset-1 col-md-9">
									<p>'.$row['content'].'</p>
								</div>
								<div class="col-md-offset-1 col-md-9">
									<div class="col-md-3">';
									$found = 0;
									$sql4 = "SELECT liked_by from post_likes where post_id =".$row['post_id']."";
									$result4 = $conn->query($sql4);
									while($row4 = $result4->fetch_assoc()){
										if ($_SESSION['userid'] == $row4['liked_by']){
											$found = 1;
										}
									}
									
									$sql5 = "SELECT count(*) as total from post_likes where post_id=".$row['post_id']."";
									$result5 = $conn->query($sql5);
									$row5 = $result5->fetch_assoc();
									$totalLikes = $row5['total'];
									if ($found == 1){
										echo '<i class="fas fa-heart" style="color:red"></i><a class="unlikeLike" id="'.$row['post_id'].'" href="#"> Unlike('.$totalLikes.')</a></div>';
									}
									else{
										echo '<i class="far fa-heart"></i><a class="unlikeLike" id="'.$row['post_id'].'" href="#"> Like('.$totalLikes.')</a></div>';
									}
									echo '<div class="col-md-3"><i class="far fa-comment"></i><a href="#" data-toggle="modal" data-target="#commentModal'.$row['post_id'].'"> Comments</a></div>
								</div>
								</div>
								
								
								
								
								
								<div class="modal fade commentModal" id="commentModal'.$row['post_id'].'" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
								  <div class="modal-dialog" role="document">
									<div class="modal-content">
									  <div class="modal-header">
										<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
										<h4 class="modal-title" id="myModalLabel">Comments</h4>
									  </div>
									  <div class="modal-body">
										<div class = "post-comment">
											<form id="postComment">
											<div class="form-group">
											  <label for="commentBox">Comment:</label>
											  <textarea class="form-control" rows="5" id="commentBox"></textarea>
											</div>
											<button type="button" class="btn btn-primary" id="newComment">Submit</button>
											</form>
										</div>
										<div class = "comments">
										</div>
										
									  </div>
									  <div class="modal-footer">
										<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
										
									  </div>
									</div>
								  </div>
								</div>';
							}
						}
						else{
							echo '<div class="col-md-12">
									<h3>No posts found</h3>
								</div>';
						}
					}
					else{
						$profID = $_GET['adminID'];
						$pageId = $_GET['page_Id'];
						$conn = new mysqli('localhost', 'root', '', 'social_network_two');
						
						// Check connection
						if ($conn->connect_error) {
							die("Connection failed: " . $conn->connect_error);
						} 
						//echo "Connected successfully";
						
						$sql8 = "SELECT * from profile where profile_id =".$_SESSION['userid']."";
						$result8 = $conn->query($sql8);
						$row8 = $result8->fetch_assoc();
						$curfname = $row8['fname'];
						$curlname = $row8['lname'];
						echo '<nav class="navbar navbar-default">
						  <div class="container-fluid">
							<div class="navbar-header">
							  
							  <a class="redirectToProfile" href="#" id="'.$row8['profile_id'].'" class="container-fluid-nav text-center"><h3>'.$curfname.' '.$curlname.'</h3></a>
							</div>
						  </div>
						</nav>';
						
						echo '<div class="container">
							<div class="row center-block">';
						$sql = "SELECT * from page where page_Id =".$pageId."";
						$result = $conn->query($sql);
						$row = $result->fetch_assoc();
						$pageName = $row['page_name'];
						$pageDesc = $row['description'];
						$pageCat = $row['category'];
						
						
						$sql2 = "SELECT * from profile where profile_id =".$profID."";
						$result2 = $conn->query($sql2);
						$row2 = $result2->fetch_assoc();
						$adminFname = $row2['fname'];
						$adminLname = $row2['lname'];
						
						echo '<div class="col-md-offset-2 col-md-10">
						<h1>'.$pageName.'</h1>
						</div>';
						echo '<div class="col-md-offset-2 col-md-7">
						<div class="col-md-12"><h4>'.$adminFname.' '.$adminLname.'</h4></div>
						<div class="col-md-12"><p><span>category: </span>'.$pageCat.'</p></div>
						<div class="col-md-12"><p><span>description: </span>'.$pageDesc.'</p></div>
						
						</br>
						</br>';
						$found = 0;
						$sql5 = "SELECT member_id from pagemembers where page_id =".$pageId."";
						$result5 = $conn->query($sql5);
						while($row5 = $result5->fetch_assoc()){
							if ($_SESSION['userid'] == $row5['member_id']){
								$found = 1;
							}
						}
						if($found == 1){
							echo '<div class="col-md-3"><i class="fas fa-user-minus"></i><a class="followUnfollow" id='.$pageId.' href="#"> unfollow</a></div>';
						}
						else{
							echo '<div class="col-md-3"><i class="fas fa-user-plus"></i><a class="followUnfollow" id='.$pageId.' href="#"> follow</a></div>';
						}
						echo '<div class="col-md-3"><i class="fas fa-users"></i><a href="#" data-toggle="modal" data-target="#viewMembers'.$pageId.'"> view members</a></div>
						</div>
					
				</div>
			</div>
			<div class = "container" style="padding-top:50px">
				<div class = "row center-block">
					<div class = "col-md-offset-1 col-md-12">';
					
						echo '<div class="col-md-offset-1 col-md-9">
							<div class = "post-post">
							<form id="postAPost">
							<div class="form-group">
							  <textarea class="form-control" rows="5" id="postBox">Whats on your mind?</textarea>
							</div>
							<button type="button" class="btn btn-primary '.$pageId.'" id="newPost">Post</button>
							</form>
						</div>
						</div>';

						
						$sql = "SELECT * from post where page_id =".$pageId."";

						$result = $conn->query($sql);
						if ($result->num_rows > 0) {
							while($row = $result->fetch_assoc()){
								$sql3 = "SELECT * from profile where profile_id =".$row['posted_by']."";
								$result3 = $conn->query($sql3);
								$row3 = $result3->fetch_assoc();
								$postedByFname = $row3['fname'];
								$postedByLname = $row3['lname'];
								echo '<div class="col-md-offset-1 col-md-9">
									<h3>'.$postedByFname.' '.$postedByLname.' : </h3>
								</div>
								<div class="col-md-offset-1 col-md-9">
									<p>'.$row['content'].'</p>
								</div>
								<div class="col-md-offset-1 col-md-9">
									<div class="col-md-3">';
									$found = 0;
									$sql4 = "SELECT liked_by from post_likes where post_id =".$row['post_id']."";
									$result4 = $conn->query($sql4);
									while($row4 = $result4->fetch_assoc()){
										if ($_SESSION['userid'] == $row4['liked_by']){
											$found = 1;
										}
									}
									
									$sql5 = "SELECT count(*) as total from post_likes where post_id=".$row['post_id']."";
									$result5 = $conn->query($sql5);
									$row5 = $result5->fetch_assoc();
									$totalLikes = $row5['total'];
									if ($found == 1){
										echo '<i class="fas fa-heart" style="color:red;"></i><a class="unlikeLike" id="'.$row['post_id'].'" href="#"> Unlike('.$totalLikes.')</a></div>';
									}
									else{
										echo '<i class="far fa-heart"></i><a class="unlikeLike" id="'.$row['post_id'].'" href="#"> Like('.$totalLikes.')</a></div>';
									}
									echo '<div class="col-md-3"><i class="far fa-comment"></i><a href="#" data-toggle="modal" data-target="#commentModal'.$row['post_id'].'"> Comments</a></div>
								</div>
								
								
								
								
								
								<div class="modal fade commentModal" id="commentModal'.$row['post_id'].'" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
								  <div class="modal-dialog" role="document">
									<div class="modal-content">
									  <div class="modal-header">
										<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
										<h4 class="modal-title" id="myModalLabel">Comments</h4>
									  </div>
									  <div class="modal-body">
										<div class = "post-comment">
											<form id="postComment">
											<div class="form-group">
											  <label for="commentBox">Comment:</label>
											  <textarea class="form-control" rows="5" id="commentBox"></textarea>
											</div>
											<button type="button" class="btn btn-primary" id="newComment">Submit</button>
											</form>
										</div>
										<div class = "comments">
										</div>
										
									  </div>
									  <div class="modal-footer">
										<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
										
									  </div>
									</div>
								  </div>
								</div>';
							}
						}
						else{
							echo '<div class="col-md-12">
									<h3>No posts found</h3>
								</div>';
						}
					}
				}
			
			echo '</div>
		</div>
	</div>';
	
	
	
	echo '<div class="modal fade view-members" id="viewMembers'.$pageId.'" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
	  <div class="modal-dialog" role="document">
		<div class="modal-content">
		  <div class="modal-header">
			<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
			<h4 class="modal-title" id="myModalLabel">View Members</h4>
		  </div>
		  <div class="modal-body">
				<div class="memberList">
				</div>
		  </div>
		  <div class="modal-footer">
			<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
			
		  </div>
		</div>
	  </div>
	</div>';
	
	
	echo '<div class="modal fade view-members" id="deletePage'.$pageId.'" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
	  <div class="modal-dialog" role="document">
		<div class="modal-content">
		  <div class="modal-header">
			<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
			<h4 class="modal-title" id="myModalLabel">Delete page</h4>
		  </div>
		  <div class="modal-body">
				<h3>Are you sure you want to delete this page?</h3>
		  </div>
		  <div class="modal-footer">
			<button type="button" class="btn btn-default" data-dismiss="modal">No</button>
			<button type="button" class="btn btn-primary deleteYes" id="'.$pageId.'">Yes</button>
		  </div>
		</div>
	  </div>
	</div>
	
	
	
	
	<div class="modal fade upPage" id="updatePage'.$pageId.'" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="myModalLabel">Update Page</h4>
      </div>
      <div class="modal-body">
			<form class="form-horizontal" id="pageCreate">
				  <div class="form-group">
					<label for="pageName" class="col-sm-2 control-label">Page Name</label>
					<div class="col-sm-10">
					  <input type="text" class="form-control" id="pageName" placeholder="Page name">
					</div>
				  </div>
				  <div class="form-group">
					<label for="pageDescription" class="col-sm-2 control-label">Description</label>
					<div class="col-sm-10">
					  <input type="text" class="form-control" id="pageDescription" placeholder="Description">
					</div>
				  </div>
				  <div class="form-group">
					<label for="pageCategory" class="col-sm-2 control-label">Category</label>
					<div class="col-sm-10">
					  <input type="text" class="form-control" id="pageCategory" placeholder="Category">
					</div>
				  </div>
				  
				</form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary" id="pageUpdate">Save changes</button>
      </div>
    </div>
  </div>
</div>';
?>

	<!-- jquery CDN -->
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
	<!-- Latest compiled and minified JavaScript -->
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
	
	<script type="text/javascript">
		$(function(){
		  $('.unlikeLike').click(function(){
			var postId = $(this).attr('id');
			////alert(postId);
			var res;
			$.ajax({
				url: 'likeUnlike.php',
				type: 'GET',
				data: {'post_Id': postId},
				success: function(response){
					res = JSON.parse(response);
					////alert(response);
					var newPageId = res[0]['page_id'];
					var adminID=res[0]['admin_id'];
					////alert(adminID);
					var link = "http://localhost/page.php?page_Id="+newPageId+"&adminID="+adminID+"";
					window.location.assign(link); 
					
				}
				
			});
			//window.location.assign("http://localhost/index.php");
		  });
		});
		
		
		$('.commentModal').on('shown.bs.modal', function () {
		  var id = $(this).attr('id');
		  var postId = id.match(/\d+$/)[0];
		  ////alert(postId);
		  var res;
		  var output = '';
			$.ajax({
				url: 'viewComments.php',
				type: 'GET',
				data: {'post_Id': postId},
				success: function(response){
					$( ".comments" ).empty();
					res = JSON.parse(response);
					////alert(response);
					for(var i in res){
						output += '<div class="container">'; 
						output += '<div class="row">';
						output += '<div class = "col-md-12">';
						output += '<h4>'+res[i].commenter_fname+' '+res[i].commenter_lname+' <small>'+res[i].comment_date+'</small> :</h4>';
						
						output += '</div>';
						output += '<div class = "col-md-12">';
						output += '<blockquote><p>'+res[i].comment_text+'</p></blockquote>';
						output += '</div>';
						output += '</div>';
						output += '</div>';
					}
					////alert(output);
					$( ".comments" ).append( output );
					
				}
				
			});
			
			$("#newComment").click(function(){
			var commentText = $("#commentBox").val();
			var output = '';
			var res;
			//alert(commentText);
			$.ajax({
				url: 'postComments.php',
				type: 'GET',
				data: {'post_Id': postId, 'comment_text': commentText},
				success: function(response){
					//alert(response);
					$( ".comments" ).empty();
					res = JSON.parse(response);
					
					
					for(var i in res){
						output += '<div class="container">'; 
						output += '<div class="row">';
						output += '<div class = "col-md-12">';
						output += '<h4>'+res[i].commenter_fname+' '+res[i].commenter_lname+' <small>'+res[i].comment_date+'</small> :</h4>';
						
						output += '</div>';
						output += '<div class = "col-md-12">';
						output += '<blockquote><p>'+res[i].comment_text+'</p></blockquote>';
						output += '</div>';
						output += '</div>';
						output += '</div>';
					}
					//alert(output);
					$( ".comments" ).append( output );
					
				}
				
			});
			
		});
			
			
		});
		
		
		$('.view-members').on('shown.bs.modal', function () {
		  var id = $(this).attr('id');
		  var pageId = id.match(/\d+$/)[0];
		  ////alert(pageId);
		  var res;
		  var output = '';
			$.ajax({
				url: 'viewMembers.php',
				type: 'GET',
				data: {'page_Id': pageId},
				success: function(response){
					$( ".memberList" ).empty();
					res = JSON.parse(response);
					////alert(response);
					for(var i in res){
						output += '<div class="container">'; 
						output += '<div class="row">';
						output += '<div class = "col-md-12">';
						output += '<h4>'+res[i].fname+' '+res[i].lname+'</h4>';
						
						output += '</div>';
						
						
					}
					////alert(output);
					$( ".memberList" ).append( output );
					
				}
				
			});
		
		});
		
		
		$("#newPost").click(function(){
			var postText = $("#postBox").val();
			////alert(postText);
			var id = $(this).attr('class');
			////alert(id);
			var pageId = id.match(/\d+$/)[0];
			var output = '';
			var res;
			////alert(pageId);
			$.ajax({
				url: 'newPost.php',
				type: 'GET',
				data: {'page_Id': pageId, 'post_text': postText},
				success: function(response){
					//alert(response);
					res = JSON.parse(response);
					//alert(res);
					var newPageId = res[0]['page_ID'];
					var adminID=res[0]['adminID'];
					////alert(adminID);
					var link = "http://localhost/page.php?page_Id="+newPageId+"&adminID="+adminID+"";
					window.location.assign(link);
					
					
					
					}
					
				
				
			});
			
		});
		
		$(function(){
		  $('.redirectToProfile').click(function(){
			var profId = $(this).attr('id');
			////alert(postId);
			var res;
			$.ajax({
				url: 'redirectToProfile.php',
				type: 'GET',
				data: {'profile_Id': profId},
				success: function(response){
					////alert(response);
					res = JSON.parse(response);
					var uid=res[0]['profile_id'];
					var fname=res[0]['first_name'];
					var lname=res[0]['last_name'];
					var uname=res[0]['u_name'];
					var mobNo=res[0]['mobile_no'];
					var eId=res[0]['eId'];
					
					var link = "http://localhost/profile.php?profileID="+uid+"&fname="+fname+"&lname="+lname+"&uname="+uname+"&mobNo="+mobNo+"&eid="+eId+"";
					window.location.assign(link); 
				}
				
			});
			//window.location.assign("http://localhost/index.php");
		  });
		});
		
		
		$(function(){
		  $('.followUnfollow').click(function(){
			var pageId = $(this).attr('id');
			////alert(postId);
			var res;
			$.ajax({
				url: 'followUnfollow.php',
				type: 'GET',
				data: {'page_Id': pageId},
				success: function(response){
					////alert(response);
					res = JSON.parse(response);
					////alert(response);
					var newPageId = res[0]['page_id'];
					var adminID=res[0]['admin_id'];
					////alert(adminID);
					var link = "http://localhost/page.php?page_Id="+newPageId+"&adminID="+adminID+"";
					window.location.assign(link); 
					
				}
				
			});
			//window.location.assign("http://localhost/index.php");
		  });
		});
		
		
		
		$(function(){
		  $('.deleteYes').click(function(){
			var pageId = $(this).attr('id');
			var res;
			$.ajax({
				url: 'deletePage.php',
				type: 'GET',
				data: {'page_id': pageId},
				success: function(response){
					//alert(response);
					res = JSON.parse(response);
					var uid=res[0]['profile_id'];
					var fname=res[0]['first_name'];
					var lname=res[0]['last_name'];
					var uname=res[0]['u_name'];
					var mobNo=res[0]['mobile_no'];
					var eId=res[0]['eId'];
					
					var link = "http://localhost/profile.php?profileID="+uid+"&fname="+fname+"&lname="+lname+"&uname="+uname+"&mobNo="+mobNo+"&eid="+eId+"";
					window.location.assign(link); 
					
				}
				
			});
			//window.location.assign("http://localhost/index.php");
		  });
		});
		
		
		
		$('.upPage').on('shown.bs.modal', function () {
			var id = $(this).attr('id');
			////alert(id);
		  //var pagetId = id.substr(id.length - 1);
		  var pagetId = id.match(/\d+$/)[0];
		  ////alert(pagetId);
		$(function(){
		  $('#pageUpdate').click(function(){
			var pname = $("#pageName").val();
			var pdesc = $("#pageDescription").val();
			var pcat = $("#pageCategory").val();
			////alert(pname);
			////alert(pdesc);
			////alert(pcat);
			var res;
			$.ajax({
				url: 'updatePage.php',
				type: 'GET',
				data: {'page_name': pname, 'page_desc': pdesc, 'page_cat': pcat, 'page_id':pagetId},
				success: function(response){
					//alert(response);
					res = JSON.parse(response);
					////alert(response);
					var newPageId = res[0]['page_ID'];
					var adminID=res[0]['adminID'];
					////alert(adminID);
					var link = "http://localhost/page.php?page_Id="+newPageId+"&adminID="+adminID+"";
					window.location.assign(link); 
					
				}
				
			});
			//window.location.assign("http://localhost/index.php");
		  });
		});
		});
		
		
		
		$(".datePick").click(function(){
			var datePicked = $("#pickDate").val();
			//alert(datePicked);
			var id = $(this).attr('id');
		  var pageId = id.match(/\d+$/)[0];
			
			var res;
			//alert(pageId);
			
			$.ajax({
				url: 'getDateData.php',
				type: 'GET',
				data: {'date': datePicked, 'page_Id': pageId},
				success: function(response){
					alert(response);
					$( ".postsToAppend" ).empty();
					res = JSON.parse(response);
					
					var output = '';
					for(var i in res){
						output += '<div class="col-md-offset-1 col-md-9">';
						output += '			<h3>'+res[i].postedByFname+' '+res[i].postedByLname+' : </h3>';
						output += '		</div>';
						output += '		<div class="col-md-offset-1 col-md-9">';
						output += '			<p>'+res[i].postContent+'</p>';
						output += '		</div>';
						output += '		<div class="col-md-offset-1 col-md-9">';
						output += '			<div class="col-md-3">';
						if(res[i].found == 1){
							output += '<i class="fas fa-heart" style="color:red;"></i><a class="unlikeLike" id="'+res[i].postID+'" href="#"> Unlike('+res[i].totalLikes+')</a></div>';
						}
						else{
							output += '<i class="far fa-heart"></i><a class="unlikeLike" id="'+res[i].postID+'" href="#"> Like('+res[i].totalLikes+')</a></div>';
						}
							output += '<div class="col-md-3"><i class="far fa-comment"></i><a href="#" data-toggle="modal" data-target="#commentModal'+res[i].postID+'"> Comments</a></div>';
							output += '</div>';
						
					}
					alert(output);
					$( ".postsToAppend" ).empty();
					$( ".postsToAppend" ).append( output );
					
				}
				
			});
			
		});
	</script>
	
</body>

