<?php
session_start();
$found = 0;
$postId = $_GET['post_Id'];
$newComment = $_GET['comment_text'];
$commentDetails = array();
$conn = new mysqli('localhost', 'root', '', 'social_network_two');

// Check connection
if ($conn->connect_error) {
	die("Connection failed: " . $conn->connect_error);
} 
$sql2 = "INSERT INTO comment (comment_text, comment_date, commenter_id, post_id) VALUES ('".$newComment."', CURRENT_TIMESTAMP, ".$_SESSION['userid'].", ".$postId.")";
$result2 = $conn->query($sql2);

$sql = "SELECT * from comment where post_id =".$postId."";

$result = $conn->query($sql);
if ($result->num_rows > 0) {
	while($row = $result->fetch_assoc()){
		$sql2 = "SELECT * from profile where profile_id =".$row['commenter_id']."";
		$result2 = $conn->query($sql2);
		$row2 = $result2->fetch_assoc();
		$commented_by_fname = $row2['fname'];
		$commented_by_lname = $row2['lname'];
		$commentDetails[] = array(
						'comment_id' => $row['comment_id'],
						'comment_text' => $row['comment_text'],
						'comment_date' => $row['comment_date'],
						'commenter_fname' => $commented_by_fname,
						'commenter_lname' => $commented_by_lname,
						'post_id' => $row['post_id']
		);
	}
	echo json_encode($commentDetails);
}
else{
	echo '<div class="col-md-12">
			<h3>No pages found</h3>
		</div>';
}
?>