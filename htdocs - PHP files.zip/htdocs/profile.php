<!DOCTYPE HTML>
<html>
<head>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

	<!-- Optional theme -->
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">
	
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.5.0/css/all.css" integrity="sha384-B4dIYHKNBt8Bc12p+WXckhzcICo0wtJAoU8YZTY5qE0Id1GSseTk6S+L3BlXeVIU" crossorigin="anonymous">
	
	<style type="text/css">
		a:link{
			text-decoration:none;
		}
	</style>
</head>
<body style="color:#6d6d6d;">

	
	
			<?php
				session_start();
				if(!isset($_SESSION['userid']))
				{
						header("location: index.php");
				}
				else{
					if($_SESSION['userid'] == $_GET['profileID']){
				
						$profID = $_GET['profileID'];
						$firstName = $_GET['fname'];
						$lastName = $_GET['lname'];
						$userName = $_GET['uname'];
						$number = $_GET['mobNo'];
						
						$conn = new mysqli('localhost', 'root', '', 'social_network_two');
						
						// Check connection
						if ($conn->connect_error) {
							die("Connection failed: " . $conn->connect_error);
						} 
						//echo "Connected successfully";
						
						$sql8 = "SELECT * from profile where profile_id =".$_SESSION['userid']."";
						$result8 = $conn->query($sql8);
						$row8 = $result8->fetch_assoc();
						$curfname = $row8['fname'];
						$curlname = $row8['lname'];
						echo '<nav class="navbar navbar-default">
						  <div class="container-fluid">
							<div class="navbar-header">
							  
							  <a class="redirectToProfile" href="#" id="'.$row8['profile_id'].'" class="container-fluid-nav text-center"><h3>'.$curfname.' '.$curlname.'</h3></a>
							</div>
						  </div>
						</nav>';
						
						echo '<div class="container">
						<div class="row center-block">
						<div class="col-md-offset-2 col-md-1" style="border: 1px solid; border-radius: 50%; height: 85px; width: 87px; background-color: #337ab7; color: white;">
						<h1>'.$firstName[0].' '.$lastName[0].'</h1>
						</div>';
						echo '<div class="col-md-7">
						<div class="col-md-12"><h1>'.$firstName.' '.$lastName.'</h1></div>
						<div class = "col-md-12"><p>@'.$userName.'</p></div>
						</br>
						</br>
						<div class="col-md-3"><i class="far fa-plus-square"></i><a href="#" data-toggle="modal" data-target="#createPage"> create page</a></div>
						<div class="col-md-3"><i class="fas fa-search"></i><a href="#" data-toggle="modal" data-target="#findMembers"> find people</a></div>
						<div class="col-md-3"><i class="far fa-trash-alt"></i><a href="#" data-toggle="modal" data-target="#deleteProfile"> delete profile</a></div>
						<div class="col-md-3"><i class="fas fa-sign-out-alt"></i></i><a id="logout" href="#"> logout</a></div>
						</div>
					
				</div>
			</div>
			<div class = "container">
				<div class = "row center-block">
					<div class = "col-md-offset-2 col-md-10">';
					
						$conn = new mysqli('localhost', 'root', '', 'social_network_two');

						// Check connection
						if ($conn->connect_error) {
							die("Connection failed: " . $conn->connect_error);
						} 
						//echo "Connected successfully";
						
						$sql = "SELECT * from page where admin_id =".$profID."";

						$result = $conn->query($sql);
						if ($result->num_rows > 0) {
							while($row = $result->fetch_assoc()){
								echo '<div class="col-md-12">
									<a class="pageRedirect" id="'.$row['page_id'].'" href="#"><h3>'.$row['page_name'].'</h3></a>
								</div>
								<div class="col-md-12">
									<p><span>category: </span>'.$row['category'].'</p>
								</div>
								<div class="col-md-12">
									<p>'.$row['description'].'</p>
								</div>';
							}
						}
						else{
							echo '<div class="col-md-12">
									<h3>No pages found</h3>
								</div>';
						}
					}
					else{
						$profID = $_GET['profileID'];
						$firstName = $_GET['fname'];
						$lastName = $_GET['lname'];
						$userName = $_GET['uname'];
						$number = $_GET['mobNo'];
						
						$conn = new mysqli('localhost', 'root', '', 'social_network_two');
						
						// Check connection
						if ($conn->connect_error) {
							die("Connection failed: " . $conn->connect_error);
						} 
						//echo "Connected successfully";
						
						$sql8 = "SELECT * from profile where profile_id =".$_SESSION['userid']."";
						$result8 = $conn->query($sql8);
						$row8 = $result8->fetch_assoc();
						$curfname = $row8['fname'];
						$curlname = $row8['lname'];
						echo '<nav class="navbar navbar-default">
						  <div class="container-fluid">
							<div class="navbar-header">
							  
							  <a class="redirectToProfile" href="#" id="'.$row8['profile_id'].'" class="container-fluid-nav text-center"><h3>'.$curfname.' '.$curlname.'</h3></a>
							</div>
						  </div>
						</nav>';
						
						echo '<div class="container">
						<div class="row center-block">
						<div class="col-md-offset-2 col-md-1" style="border: 1px solid; border-radius: 50%; height: 85px; width: 87px;  background-color: #337ab7; color: white;">
						<h1>'.$firstName[0].' '.$lastName[0].'</h1>
						</div>';
						echo '<div class="col-md-7">
						<div class="col-md-12"><h1>'.$firstName.' '.$lastName.'</h1></div>
						<div class = "col-md-12"><p>@'.$userName.'</p></div>
						</br>
						</br>
						</div>
					
				</div>
			</div>
			<div class = "container">
				<div class = "row center-block">
					<div class = "col-md-offset-2 col-md-10">';
					
						$conn = new mysqli('localhost', 'root', '', 'social_network_two');

						// Check connection
						if ($conn->connect_error) {
							die("Connection failed: " . $conn->connect_error);
						} 
						//echo "Connected successfully";
						
						$sql = "SELECT * from page where admin_id =".$profID."";

						$result = $conn->query($sql);
						if ($result->num_rows > 0) {
							while($row = $result->fetch_assoc()){
								echo '<div class="col-md-12">
									<a class="pageRedirect" id="'.$row['page_id'].'" href="#"><h3>'.$row['page_name'].'</h3></a>
								</div>
								<div class="col-md-12">
									<p><span>category: </span>'.$row['category'].'</p>
								</div>
								<div class="col-md-12">
									<p>'.$row['description'].'</p>
								</div>';
							}
						}
						else{
							echo '<div class="col-md-12">
									<h3>No pages found</h3>
								</div>';
						}
					}
				}
			?>
			</div>
		</div>
	</div>
	
	
	
	
	<div class="modal fade" id="createPage" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="myModalLabel">Create Page</h4>
      </div>
      <div class="modal-body">
			<form class="form-horizontal" id="pageCreate">
				  <div class="form-group">
					<label for="pageName" class="col-sm-2 control-label">Page Name</label>
					<div class="col-sm-10">
					  <input type="text" class="form-control" id="pageName" placeholder="Page name">
					</div>
				  </div>
				  <div class="form-group">
					<label for="pageDescription" class="col-sm-2 control-label">Description</label>
					<div class="col-sm-10">
					  <input type="text" class="form-control" id="pageDescription" placeholder="Description">
					</div>
				  </div>
				  <div class="form-group">
					<label for="pageCategory" class="col-sm-2 control-label">Category</label>
					<div class="col-sm-10">
					  <input type="text" class="form-control" id="pageCategory" placeholder="Category">
					</div>
				  </div>
				  
				</form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary" id="newPage">Save changes</button>
      </div>
    </div>
  </div>
</div>

<?php
echo '<div class="modal fade view-members" id="deleteProfile" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
	  <div class="modal-dialog" role="document">
		<div class="modal-content">
		  <div class="modal-header">
			<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
			<h4 class="modal-title" id="myModalLabel">Delete page</h4>
		  </div>
		  <div class="modal-body">
				<h3>Are you sure you want to delete this page?</h3>
		  </div>
		  <div class="modal-footer">
			<button type="button" class="btn btn-default" data-dismiss="modal">No</button>
			<button type="button" class="btn btn-primary deleteProfYes" id="'.$_GET['profileID'].'">Yes</button>
		  </div>
		</div>
	  </div>
	</div>';

?>




	<div class="modal fade" id="findMembers" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="myModalLabel">Find members</h4>
      </div>
      <div class="modal-body">
			<div class="container">
				<div class = "row">
					<div class="col-md-10">
						<?php
							$conn = new mysqli('localhost', 'root', '', 'social_network_two');

						// Check connection
						if ($conn->connect_error) {
							die("Connection failed: " . $conn->connect_error);
						} 
						//echo "Connected successfully";
						
						$sql = "SELECT * from profile";

						$result = $conn->query($sql);
						if ($result->num_rows > 0) {
							while($row = $result->fetch_assoc()){
								echo '<div class="col-md-12">
									<a class="visitProfile" id="'.$row['profile_id'].'" href="#"><h3>'.$row['fname'].' '.$row['lname'].'</h3></a>
								</div>';
							}
						}
						else{
							echo '<div class="col-md-12">
									<h3>No pages found</h3>
								</div>';
						}
						?>
					</div>
				</div>
			</div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        
      </div>
    </div>
  </div>
</div>
	<!-- jquery CDN -->
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
	<!-- Latest compiled and minified JavaScript -->
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
	
	<script type="text/javascript">
		$(function(){
		  $('.pageRedirect').click(function(){
			var pageId = $(this).attr('id');
			////alert(pageId);
			var res;
			$.ajax({
				url: 'fetchpagedetails.php',
				type: 'GET',
				data: {'page_Id': pageId},
				success: function(response){
					res = JSON.parse(response);
					////alert(response);
					var newPageId = res[0]['page_ID'];
					var adminID=res[0]['adminID'];
					////alert(adminID);
					var link = "http://localhost/page.php?page_Id="+newPageId+"&adminID="+adminID+"";
					window.location.assign(link); 
					
				}
				
			});
			//window.location.assign("http://localhost/index.php");
		  });
		});
		
		
		$(function(){
		  $('.redirectToProfile').click(function(){
			var profId = $(this).attr('id');
			////alert(postId);
			var res;
			$.ajax({
				url: 'redirectToProfile.php',
				type: 'GET',
				data: {'profile_Id': profId},
				success: function(response){
					////alert(response);
					res = JSON.parse(response);
					var uid=res[0]['profile_id'];
					var fname=res[0]['first_name'];
					var lname=res[0]['last_name'];
					var uname=res[0]['u_name'];
					var mobNo=res[0]['mobile_no'];
					var eId=res[0]['eId'];
					
					var link = "http://localhost/profile.php?profileID="+uid+"&fname="+fname+"&lname="+lname+"&uname="+uname+"&mobNo="+mobNo+"&eid="+eId+"";
					window.location.assign(link); 
				}
				
			});
			//window.location.assign("http://localhost/index.php");
		  });
		});
		
		$(function(){
		  $('#newPage').click(function(){
			var pname = $("#pageName").val();
			var pdesc = $("#pageDescription").val();
			var pcat = $("#pageCategory").val();
			//alert(pname);
			var res;
			$.ajax({
				url: 'createPage.php',
				type: 'GET',
				data: {'page_name': pname, 'page_desc': pdesc, 'page_cat': pcat},
				success: function(response){
					//alert(response);
					res = JSON.parse(response);
					////alert(response);
					var newPageId = res[0]['page_ID'];
					var adminID=res[0]['adminID'];
					////alert(adminID);
					var link = "http://localhost/page.php?page_Id="+newPageId+"&adminID="+adminID+"";
					window.location.assign(link); 
					
				}
				
			});
			//window.location.assign("http://localhost/index.php");
		  });
		});
		
		
		
		$(function(){
		  $('.visitProfile').click(function(){
			var profId = $(this).attr('id');
			////alert(postId);
			var res;
			$.ajax({
				url: 'redirectToProfile.php',
				type: 'GET',
				data: {'profile_Id': profId},
				success: function(response){
					////alert(response);
					res = JSON.parse(response);
					var uid=res[0]['profile_id'];
					var fname=res[0]['first_name'];
					var lname=res[0]['last_name'];
					var uname=res[0]['u_name'];
					var mobNo=res[0]['mobile_no'];
					var eId=res[0]['eId'];
					
					var link = "http://localhost/profile.php?profileID="+uid+"&fname="+fname+"&lname="+lname+"&uname="+uname+"&mobNo="+mobNo+"&eid="+eId+"";
					window.location.assign(link); 
				}
				
			});
			//window.location.assign("http://localhost/index.php");
		  });
		});
		
		
		$(function(){
		  $('.deleteProfYes').click(function(){
			var profileId = $(this).attr('id');
			var res;
			$.ajax({
				url: 'deleteProfile.php',
				type: 'GET',
				data: {'profile_id': profileId},
				success: function(response){
					//alert(response);
					
					var link = "http://localhost/index.php"
					window.location.assign(link); 
					
				}
				
			});
			//window.location.assign("http://localhost/index.php");
		  });
		});
		
		$(function(){
		  $('#logout').click(function(){
			var profileId = $(this).attr('id');
			//alert("inside");
			var res;
			$.ajax({
				url: 'logout.php',
				type: 'GET',
				data: {'profile_id': profileId},
				success: function(response){
					//alert(response);
					
					var link = "http://localhost/index.php"
					window.location.assign(link); 
					
				}
				
			});
			//window.location.assign("http://localhost/index.php");
		  });
		});
	</script>
	
</body>


<?php
//PROFILE PAGE
$profID = $_GET['profileID'];
$firstName = $_GET['fname'];
$lastName = $_GET['lname'];
$userName = $_GET['uname'];
$number = $_GET['mobNo'];
?>
