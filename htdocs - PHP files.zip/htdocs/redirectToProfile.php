<?php
session_start();
$prof_id = $_GET['profile_Id'];
//echo $uname;
// Create connection
$userDetails = array();
$conn = new mysqli('localhost', 'root', '', 'social_network_two');

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
//echo "Connected successfully";

$sql2 = "SELECT * from profile where profile_id like '%".$prof_id."%'";
$result = $conn->query($sql2);
$row1 = $result->fetch_assoc();
$pid = $row1['profile_id'];
$fname = $row1['fname'];
$lname = $row1['lname'];
$username = $row1['username'];
$mobile_no = $row1['mobile_no'];
$email = $row1['email'];


	

$userDetails[] = array(
						'profile_id' => $pid,
						'first_name' => $fname,
						'last_name' => $lname,
						'u_name' => $username,
						'mobile_no' => $mobile_no,
						'eId' => $email
);
	
echo json_encode($userDetails);


$conn->close();
?>