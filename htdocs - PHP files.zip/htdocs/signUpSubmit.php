<?php
//SIGN UP FORM SUBMIT PAGE
$email = $_GET['eSignIn'];
$password = $_GET['psswd'];
$firstName = $_GET['fname'];
$lastName = $_GET['lname'];
$userName = $_GET['uname'];
$number = $_GET['mobNo'];
$creationDate = date("Y-m-d");
$conn = new mysqli('localhost', 'root', '', 'social_network_two');

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
//echo "Connected successfully";
$sql = "INSERT INTO profile ( fname, lname, email, pwd, username, mobile_no, prof_create_date) VALUES ('".$firstName."','".$lastName."','".$email."','".$password."','".$userName."',".$number.",'".$creationDate."')";

//$result = $conn->query($sql);
if ($conn->query($sql) === TRUE) {
    //echo "New record created successfully";
	$sql2 = "select * from profile where email like '%".$email."%';";
	$result = $conn->query($sql2);
	$row1 = $result->fetch_assoc();
	
	$pid = $row1['profile_id'];
	$fname = $row1['fname'];
	$lname = $row1['lname'];
	$username = $row1['username'];
	$mobile_no = $row1['mobile_no'];
	
	$userDetails[] = array(
							'profile_id' => $pid,
							'first_name' => $fname,
							'last_name' => $lname,
							'u_name' => $username,
							'mobile_no' => $mobile_no
	);
	echo json_encode($userDetails);
	
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>


