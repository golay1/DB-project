<?php
session_start();
$found = 0;
$pageName = $_GET['page_name'];
$pageDesc = $_GET['page_desc'];
$pageCat = $_GET['page_cat'];
$pageId = $_GET['page_id'];
$pageDetails = array();
$conn = new mysqli('localhost', 'root', '', 'social_network_two');

// Check connection
if ($conn->connect_error) {
	die("Connection failed: " . $conn->connect_error);
} 


	$sql2 = 'UPDATE `page` SET `page_name`="'.$pageName.'", `description`="'.$pageDesc.'",`category`="'.$pageCat.'" WHERE `admin_id`='.$_SESSION['userid'].' and page_id ='.$pageId.'';
	
	$result2 = $conn->query($sql2);

$sql = "SELECT * from page where page_id = '".$pageId."'";

$result = $conn->query($sql);
$row = $result->fetch_assoc();
$adminID = $row['admin_id'];
$pageId = $row['page_id'];

$pageDetails[] = array(
						'page_ID' => $pageId,
						'adminID' => $adminID
		);

echo json_encode($pageDetails);

?>