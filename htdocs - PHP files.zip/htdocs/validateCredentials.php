<?php
$uname = $_GET['eSignIn'];
$pwd = $_GET['psswd'];
//echo $uname;
// Create connection
$userDetails = array();
$conn = new mysqli('localhost', 'root', '', 'social_network_two');

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
//echo "Connected successfully";
$sql = "SELECT pwd from profile where email like '%".$uname."%'";

$result = $conn->query($sql);
$row = $result->fetch_assoc();
$password = $row['pwd'];
//echo $password;
if($pwd == $password){
	//echo "True";
	
	$sql2 = "SELECT *from profile where email like '%".$uname."%'";
	$result = $conn->query($sql2);
	$row1 = $result->fetch_assoc();
	$pid = $row1['profile_id'];
	$fname = $row1['fname'];
	$lname = $row1['lname'];
	$username = $row1['username'];
	$mobile_no = $row1['mobile_no'];
	
	
	if(isset($uname))
	{
			session_start();
			$_SESSION['userid']= $pid;
			//Storing the name of user in SESSION variable.
	}
	
	
	$userDetails[] = array(
							'profile_id' => $pid,
							'first_name' => $fname,
							'last_name' => $lname,
							'u_name' => $username,
							'mobile_no' => $mobile_no,
							'eId' => $uname
	);
	
	echo json_encode($userDetails);
}
else{
	echo "False";
	
}

$conn->close();
?>