<?php
session_start();
$found = 0;
$pageId = $_GET['page_Id'];
$userdetails = array();
$conn = new mysqli('localhost', 'root', '', 'social_network_two');

$sql =" select member_id from pagemembers where page_id = ".$pageId."";

$result = $conn->query($sql);
if ($result->num_rows > 0) {
	while($row = $result->fetch_assoc()){
		$sql2 = " Select * from profile where profile_id = ".$row['member_id']."";
		$result2 = $conn->query($sql2);
		$row2 = $result2->fetch_assoc();
		$userdetails[] = array(
						'fname' => $row2['fname'],
						'lname' => $row2['lname'],
						'id' => $row2['profile_id']
		);
	}
	echo json_encode($userdetails);
}
?>